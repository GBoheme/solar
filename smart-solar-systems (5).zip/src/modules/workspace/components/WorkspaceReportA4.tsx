import React from 'react';
import { useWorkspaceStore } from '../../../store/workspaceStore';
import { useCurrencyStore } from '../../../store/currencyStore';
import { Sun, Battery, Zap, Shield, CheckCircle2 } from 'lucide-react';

export default function WorkspaceReportA4() {
  const { config, result, selectedComponents, loads } = useWorkspaceStore();
  const { formatPrice } = useCurrencyStore();

  // If calculation hasn't run yet, nothing to print
  if (!result || !result.engineering || !result.pricing) {
    return null;
  }

  const recommendation = result.recommendation;
  
  const selectedPanelModel = recommendation?.panels?.item ? `${recommendation.panels.item.brand} - ${recommendation.panels.item.model}` : 'لوح شمسي';
  const selectedBatteryModel = recommendation?.batteries?.item ? `${recommendation.batteries.item.brand} - ${recommendation.batteries.item.model}` : 'بطاريات تخزين';
  const selectedInverterModel = recommendation?.inverter?.item ? `${recommendation.inverter.item.brand} - ${recommendation.inverter.item.model}` : 'إنفرتر شمسي';

  // Calculate generic daily kwh
  const totalDailyKwh = (loads.reduce((sum, load) => sum + (load.watts * load.quantity * load.hoursDaily), 0) / 1000).toFixed(1);

  return (
    <div className="hidden print:flex w-full justify-center bg-white absolute top-0 left-0 z-50">
      {/* Exact A4 Dimensions: 210mm x 297mm */}
      <div className="w-[210mm] h-[297mm] bg-white relative overflow-hidden flex flex-col">

        {/* 1. Header (Compact) */}
        <div className="bg-slate-900 text-white p-6 shrink-0 relative flex justify-between items-center">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/20 rounded-full -mr-16 -mt-16 blur-2xl" />

          <div className="relative z-10 flex items-center gap-4">
            <div className="p-3 bg-amber-500 rounded-xl text-slate-900">
              <Sun className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-amber-500 tracking-tight">الشمس الذكية</h1>
              <p className="text-slate-300 text-xs font-medium">للأنظمة الهندسية والطاقة المتجددة</p>
            </div>
          </div>

          <div className="relative z-10 text-left bg-slate-800/50 backdrop-blur-sm p-3 rounded-xl border border-slate-700">
            <h2 className="text-lg font-bold text-white mb-1">تقرير الحساب المتقدم</h2>
            <div className="text-xs text-slate-400 grid grid-cols-2 gap-x-4 gap-y-1">
              <span>رقم التقرير:</span>
              <span className="font-mono text-white text-right">WS-{String(Date.now()).slice(-6)}</span>
              <span>التاريخ:</span>
              <span className="font-mono text-white text-right">{new Date().toLocaleDateString('en-GB')}</span>
            </div>
          </div>
        </div>

        <div className="px-8 py-5 flex-1 flex flex-col">

          {/* 2. Customer & Project Info (Compact Grid) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-5 grid grid-cols-3 gap-4 shrink-0">
            <div className="col-span-1 border-l border-slate-200 pl-4">
              <h3 className="text-xs font-bold text-slate-400 mb-2 uppercase">العميل</h3>
              <div className="font-bold text-slate-800 text-sm">زبون مساحة العمل</div>
              <div className="text-slate-500 text-[10px] mt-1">تحديد الحسابات المتقدمة</div>
            </div>
            <div className="col-span-1 border-l border-slate-200 pl-4">
              <h3 className="text-xs font-bold text-slate-400 mb-2 uppercase">تفاصيل النظام</h3>
              <div className="text-xs space-y-1 text-slate-600">
                <div className="flex justify-between"><span>النوع:</span> <span className="font-bold text-slate-800">{config.systemType === 'HYBRID' ? 'هجين (Hybrid)' : config.systemType === 'OFF_GRID' ? 'معزول (Off-Grid)' : 'متصل (On-Grid)'}</span></div>
                <div className="flex justify-between"><span>فولتية النظام:</span> <span className="font-bold text-slate-800 font-mono">{eng.system_voltage}V</span></div>
              </div>
            </div>
            <div className="col-span-1">
              <h3 className="text-xs font-bold text-slate-400 mb-2 uppercase">الأحمال المتوقعة</h3>
              <div className="text-xs space-y-1 text-slate-600">
                <div className="flex justify-between"><span>استهلاك يومي:</span> <span className="font-bold text-slate-800 font-mono">{totalDailyKwh} kWh</span></div>
                <div className="flex justify-between"><span>ذروة الحمل:</span> <span className="font-bold text-slate-800 font-mono">{(eng.peak_continuous_w / 1000).toFixed(1)} kW</span></div>
                <div className="flex justify-between"><span>الاستقلالية:</span> <span className="font-bold text-slate-800 font-mono">{config.autonomyHours} hrs</span></div>
              </div>
            </div>
          </div>

          {/* 3. BOM Table */}
          <div className="flex-1">
            <h3 className="text-sm font-bold text-slate-800 mb-2 flex items-center gap-2">
              <div className="w-1 h-4 bg-amber-500 rounded-full" />
              موجز المعدات المحددة والتسعير
            </h3>
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-600 border-b border-slate-200">
                    <th className="py-2 px-3 font-medium w-8 text-center">#</th>
                    <th className="py-2 px-3 font-medium w-32">الصنف</th>
                    <th className="py-2 px-3 font-medium">المواصفات / الموديل</th>
                    <th className="py-2 px-3 font-medium text-center w-12">العدد</th>
                    <th className="py-2 px-3 font-medium w-24">الإجمالي</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {eng.panel_strings.total_panels > 0 && (
                    <tr className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-center text-slate-400">1</td>
                      <td className="py-2 px-3 font-bold text-slate-800 flex items-center gap-1.5"><Sun className="w-3.5 h-3.5 text-amber-500" /> الواح</td>
                      <td className="py-2 px-3 text-slate-600 truncate max-w-[200px]">{selectedPanelModel}</td>
                      <td className="py-2 px-3 text-center font-mono font-bold">{eng.panel_strings.total_panels}</td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(pricing.panels_cost)}</td>
                    </tr>
                  )}
                  {eng.battery_bank.total_battery_count > 0 && (
                    <tr className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-center text-slate-400">2</td>
                      <td className="py-2 px-3 font-bold text-slate-800 flex items-center gap-1.5"><Battery className="w-3.5 h-3.5 text-emerald-500" /> بطاريات</td>
                      <td className="py-2 px-3 text-slate-600 truncate max-w-[200px]">{selectedBatteryModel}</td>
                      <td className="py-2 px-3 text-center font-mono font-bold">{eng.battery_bank.total_battery_count}</td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(pricing.batteries_cost)}</td>
                    </tr>
                  )}
                  <tr className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-center text-slate-400">3</td>
                    <td className="py-2 px-3 font-bold text-slate-800 flex items-center gap-1.5"><Zap className="w-3.5 h-3.5 text-blue-500" /> انفرتر</td>
                    <td className="py-2 px-3 text-slate-600 truncate max-w-[200px]">{selectedInverterModel}</td>
                    <td className="py-2 px-3 text-center font-mono font-bold">1</td>
                    <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(pricing.inverter_cost)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-center text-slate-400">4</td>
                    <td className="py-2 px-3 font-bold text-slate-800">ملحقات</td>
                    <td className="py-2 px-3 text-slate-500 text-[10px]">قواطع حماية، كابلات، هياكل تثبيت، مؤرض</td>
                    <td className="py-2 px-3 text-center font-mono">—</td>
                    <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(pricing.accessories_cost)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-center text-slate-400">5</td>
                    <td className="py-2 px-3 font-bold text-slate-800">أجور عمل</td>
                    <td className="py-2 px-3 text-slate-500 text-[10px]">نقل، تركيب، تشغيل وبرمجة النظام</td>
                    <td className="py-2 px-3 text-center font-mono">—</td>
                    <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(pricing.installation_cost)}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Additional Info / Loads Table if space permits... */}
            <div className="mt-6 border border-slate-200 rounded-xl p-4 bg-slate-50/50">
                <h4 className="text-xs font-bold text-slate-700 mb-2">توزيع وتفاصيل التكاليف</h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                        <span className="text-slate-500">إجمالي المواد: </span>
                        <span className="font-bold mr-2">{formatPrice(pricing.material_cost_usd)}</span>
                    </div>
                    <div>
                        <span className="text-slate-500">أجور العمل: </span>
                        <span className="font-bold mr-2">{formatPrice(pricing.installation_cost)}</span>
                    </div>
                </div>
            </div>
          </div>

          {/* 4. Bottom Section: Terms (Left) & Totals (Right) */}
          <div className="flex gap-6 mt-6 shrink-0">

            {/* Terms & Warranty */}
            <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-4">
              <h3 className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-500" /> الضمان والشروط العامة
              </h3>
              <ul className="text-[10px] text-slate-500 space-y-1 list-disc list-inside">
                <li>الأسعار قابلة للتغيير وتعتمد على سعر الصرف وتوفر المواد وقت التجهيز.</li>
                <li>هذا التقرير هو ناتج عن حساب برمجي مبدئي وقد يتطلب معاينة موقعية للتأكيد النهائي.</li>
                <li>تختلف شروط الضمان حسب طراز كل مكون وخيارات المورد.</li>
              </ul>
            </div>

            {/* Totals Calculation */}
            <div className="w-[240px] border border-slate-200 rounded-xl p-4 bg-white flex flex-col justify-center">
              <div className="flex justify-between items-end mb-1">
                <span className="text-sm font-bold text-slate-900">الإجمالي النهائي</span>
                <span className="text-2xl font-black text-slate-900 font-mono">{formatPrice(pricing.sale_price_usd)}</span>
              </div>
              {result.payment_options && (
                  <div className="flex justify-between items-end mt-2 pt-2 border-t border-dashed border-slate-200">
                    <span className="text-xs font-bold text-emerald-600">الدفع النقدي (بعد الخصم)</span>
                    <span className="text-sm font-black text-emerald-600 font-mono">{formatPrice(result.payment_options.cash.final_total_usd)}</span>
                  </div>
              )}
            </div>
          </div>

        </div>

        {/* 5. Footer */}
        <div className="bg-slate-100 border-t border-slate-200 p-4 shrink-0 grid grid-cols-3 text-[10px] text-slate-500">
          <div className="text-right">Smart Solar Systems © 2026</div>
          <div className="text-center"> Baghdad, Iraq | info@smartsolar.iq </div>
          <div className="text-left font-mono">Printed on: {new Date().toLocaleString('en-GB')}</div>
        </div>

      </div>
    </div>
  );
}
