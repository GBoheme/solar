import { useState, useEffect } from 'react';
import { useProjectStore } from '../store/projectStore';
import { useNavigate } from 'react-router-dom';
import { Printer, ChevronRight, Sun, Battery, Zap, Shield, CheckCircle2, Settings, User, Phone, DollarSign } from 'lucide-react';
import { useCurrencyStore } from '../store/currencyStore';

export default function QuoteView() {
  const { recommendation, region, systemType, appliances } = useProjectStore();
  const { formatPrice } = useCurrencyStore();
  const navigate = useNavigate();

  // Seller Customization State
  const [customerName, setCustomerName] = useState('عميل محتمل');
  const [customerPhone, setCustomerPhone] = useState('');

  // Default values
  const hardwareTotalBase = recommendation ?
    (recommendation.recommendation.panels.count * (recommendation.recommendation.panels.item.sale_price || 0)) +
    (recommendation.recommendation.batteries.count * (recommendation.recommendation.batteries.item.sale_price || 0)) +
    (recommendation.recommendation.inverter.item.sale_price || 0) : 0;

  const [accessoriesCost, setAccessoriesCost] = useState(hardwareTotalBase * 0.10);
  const [installationCost, setInstallationCost] = useState(hardwareTotalBase * 0.05);
  const [discount, setDiscount] = useState(0);

  const [warrantyPanels, setWarrantyPanels] = useState('25 سنة أداء');
  const [warrantyBatteries, setWarrantyBatteries] = useState('5 سنوات');
  const [warrantyInverter, setWarrantyInverter] = useState('5 سنوات');
  const [warrantyLabor, setWarrantyLabor] = useState('سنة واحدة');

  useEffect(() => {
    if (!recommendation) navigate('/');
  }, [recommendation, navigate]);

  useEffect(() => {
    if (recommendation) {
      const base = (recommendation.recommendation.panels.count * (recommendation.recommendation.panels.item.sale_price || 0)) +
        (recommendation.recommendation.batteries.count * (recommendation.recommendation.batteries.item.sale_price || 0)) +
        (recommendation.recommendation.inverter.item.sale_price || 0);
      setAccessoriesCost(base * 0.10);
      setInstallationCost(base * 0.05);
    }
  }, [recommendation]);

  if (!recommendation) return null;

  const { engineering, recommendation: rec } = recommendation;

  const panelsTotal = rec.panels.count * (rec.panels.item.sale_price || 0);
  const batteriesTotal = rec.batteries.count * (rec.batteries.item.sale_price || 0);
  const inverterTotal = rec.inverter.item.sale_price || 0;
  const hardwareTotal = panelsTotal + batteriesTotal + inverterTotal;

  const subTotal = hardwareTotal + accessoriesCost + installationCost;
  const grandTotal = subTotal - discount;

  const systemTypeMap: Record<string, string> = {
    'hybrid': 'نظام مرن (هجين)',
    'off_grid': 'نظام مستقل',
    'backup': 'نظام طوارئ',
    'solar_direct': 'نظام نهاري مباشر'
  };

  const totalDailyKwh = (engineering.total_wh / 1000).toFixed(1);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row print:bg-white print:block">

      {/* ══ Seller Customization Panel (Hidden in Print) ══ */}
      <div className="w-full md:w-80 bg-white border-l border-slate-200 p-6 flex-shrink-0 print:hidden overflow-y-auto max-h-screen sticky top-0 shadow-lg z-10">
        <div className="flex items-center gap-2 mb-6 text-slate-800">
          <Settings className="w-5 h-5" />
          <h2 className="font-bold text-lg">إعدادات العرض (للبائع)</h2>
        </div>

        <div className="space-y-5">
          {/* Customer Info */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-500 border-b pb-1">معلومات العميل</h3>
            <div>
              <label className="block text-xs text-slate-500 mb-1">اسم العميل</label>
              <div className="relative">
                <User className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 pl-3 pr-9 text-sm focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">رقم الهاتف</label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="07XX-XXX-XXXX"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 pl-3 pr-9 text-sm focus:ring-2 focus:ring-amber-500 outline-none dir-ltr text-right"
                />
              </div>
            </div>
          </div>

          {/* Pricing Adjustments */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-500 border-b pb-1">تعديل التكاليف ($)</h3>
            <div>
              <label className="block text-xs text-slate-500 mb-1">تكلفة الملحقات والكابلات</label>
              <input
                type="number"
                value={Math.round(accessoriesCost)}
                onChange={(e) => setAccessoriesCost(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">أجور التركيب والنقل</label>
              <input
                type="number"
                value={Math.round(installationCost)}
                onChange={(e) => setInstallationCost(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1 text-emerald-600 font-bold">الخصم الممنوح</label>
              <div className="relative">
                <DollarSign className="w-4 h-4 absolute right-3 top-2.5 text-emerald-500" />
                <input
                  type="number"
                  value={discount}
                  onChange={(e) => setDiscount(Number(e.target.value))}
                  className="w-full bg-emerald-50 border border-emerald-200 rounded-lg py-2 pl-3 pr-9 text-sm focus:ring-2 focus:ring-emerald-500 outline-none font-mono text-emerald-700 font-bold"
                />
              </div>
            </div>
          </div>

          {/* Warranty */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-500 border-b pb-1">الضمانات</h3>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-slate-500 mb-1">الألواح</label>
                <input type="text" value={warrantyPanels} onChange={(e) => setWarrantyPanels(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg py-1.5 px-2 text-xs" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">البطاريات</label>
                <input type="text" value={warrantyBatteries} onChange={(e) => setWarrantyBatteries(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg py-1.5 px-2 text-xs" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">المحول</label>
                <input type="text" value={warrantyInverter} onChange={(e) => setWarrantyInverter(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg py-1.5 px-2 text-xs" />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">العمل</label>
                <input type="text" value={warrantyLabor} onChange={(e) => setWarrantyLabor(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg py-1.5 px-2 text-xs" />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 space-y-3">
          <button onClick={() => window.print()} className="w-full flex items-center justify-center gap-2 bg-slate-900 text-white px-4 py-3 rounded-lg font-bold hover:bg-slate-800 transition-colors shadow-lg">
            <Printer className="w-5 h-5" /> طباعة أو حفظ PDF
          </button>
          <button onClick={() => navigate(-1)} className="w-full flex items-center justify-center gap-2 bg-slate-100 text-slate-600 px-4 py-3 rounded-lg font-medium hover:bg-slate-200 transition-colors">
            <ChevronRight className="w-5 h-5" /> العودة للتصميم
          </button>
        </div>
      </div>

      {/* ══ A4 Document Area ══ */}
      <div className="flex-1 overflow-auto py-8 print:py-0 bg-slate-100 print:bg-white flex justify-center">
        {/* Exact A4 Dimensions: 210mm x 297mm */}
        <div className="w-[210mm] h-[297mm] bg-white shadow-2xl print:shadow-none relative overflow-hidden flex flex-col">

          {/* 1. Header (Compact) */}
          <div className="bg-slate-900 text-white p-6 shrink-0 relative flex justify-between items-center">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/20 rounded-full -mr-16 -mt-16 blur-2xl" />

            <div className="relative z-10 flex items-center gap-4">
              <div className="p-3 bg-amber-500 rounded-xl text-slate-900">
                <Sun className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-amber-500 tracking-tight">الشمس الذكية</h1>
                <p className="text-slate-300 text-xs font-medium">للأنظمة الهندسية والطاقة المتجددة</p>
              </div>
            </div>

            <div className="relative z-10 text-left bg-slate-800/50 backdrop-blur-sm p-3 rounded-xl border border-slate-700">
              <h2 className="text-lg font-bold text-white mb-1">عرض سعر فني</h2>
              <div className="text-xs text-slate-400 grid grid-cols-2 gap-x-4 gap-y-1">
                <span>رقم العرض:</span>
                <span className="font-mono text-white text-right">QT-{String(Date.now()).slice(-6)}</span>
                <span>التاريخ:</span>
                <span className="font-mono text-white text-right">{new Date().toLocaleDateString('en-GB')}</span>
              </div>
            </div>
          </div>

          <div className="px-8 py-5 flex-1 flex flex-col">

            {/* 2. Customer & Project Info (Compact Grid) */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-5 grid grid-cols-3 gap-4 shrink-0">
              <div className="col-span-1 border-l border-slate-200 pl-4">
                <h3 className="text-xs font-bold text-slate-400 mb-2 uppercase">معلومات العميل</h3>
                <div className="font-bold text-slate-800 text-sm">{customerName}</div>
                {customerPhone && <div className="text-slate-500 text-xs mt-1 font-mono dir-ltr text-right">{customerPhone}</div>}
              </div>
              <div className="col-span-1 border-l border-slate-200 pl-4">
                <h3 className="text-xs font-bold text-slate-400 mb-2 uppercase">تفاصيل النظام</h3>
                <div className="text-xs space-y-1 text-slate-600">
                  <div className="flex justify-between"><span>النوع:</span> <span className="font-bold text-slate-800">{systemTypeMap[systemType] || systemType}</span></div>
                  <div className="flex justify-between"><span>الجهد:</span> <span className="font-bold text-slate-800 font-mono">{engineering.system_voltage}V</span></div>
                  <div className="flex justify-between"><span>الموقع:</span> <span className="font-bold text-slate-800">{region?.name}</span></div>
                </div>
              </div>
              <div className="col-span-1">
                <h3 className="text-xs font-bold text-slate-400 mb-2 uppercase">الأحمال المتوقعة</h3>
                <div className="text-xs space-y-1 text-slate-600">
                  <div className="flex justify-between"><span>استهلاك يومي:</span> <span className="font-bold text-slate-800 font-mono">{totalDailyKwh} kWh</span></div>
                  <div className="flex justify-between"><span>ذروة الحمل:</span> <span className="font-bold text-slate-800 font-mono">{(engineering.peak_continuous_w / 1000).toFixed(1)} kW</span></div>
                  <div className="flex justify-between"><span>الاستقلالية:</span> <span className="font-bold text-slate-800 font-mono">{engineering.autonomy_hours} hrs</span></div>
                </div>
              </div>
            </div>

            {/* 3. BOM Table */}
            <div className="flex-1">
              <h3 className="text-sm font-bold text-slate-800 mb-2 flex items-center gap-2">
                <div className="w-1 h-4 bg-amber-500 rounded-full" />
                قائمة المعدات الفنية
              </h3>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 border-b border-slate-200">
                      <th className="py-2 px-3 font-medium w-8 text-center">#</th>
                      <th className="py-2 px-3 font-medium w-32">الصنف</th>
                      <th className="py-2 px-3 font-medium">المواصفات / الموديل</th>
                      <th className="py-2 px-3 font-medium text-center w-12">العدد</th>
                      <th className="py-2 px-3 font-medium w-20">ع.مفرد</th>
                      <th className="py-2 px-3 font-medium w-24">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {rec.panels.count > 0 && (
                      <tr className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-center text-slate-400">1</td>
                        <td className="py-2 px-3 font-bold text-slate-800 flex items-center gap-1.5"><Sun className="w-3.5 h-3.5 text-amber-500" /> الواح</td>
                        <td className="py-2 px-3 text-slate-600 truncate max-w-[150px]">{rec.panels.item.model}</td>
                        <td className="py-2 px-3 text-center font-mono font-bold">{rec.panels.count}</td>
                        <td className="py-2 px-3 font-mono">{formatPrice(rec.panels.item.sale_price)}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(panelsTotal)}</td>
                      </tr>
                    )}
                    {rec.batteries.count > 0 && (
                      <tr className="hover:bg-slate-50">
                        <td className="py-2 px-3 text-center text-slate-400">2</td>
                        <td className="py-2 px-3 font-bold text-slate-800 flex items-center gap-1.5"><Battery className="w-3.5 h-3.5 text-emerald-500" /> بطاريات</td>
                        <td className="py-2 px-3 text-slate-600 truncate max-w-[150px]">{rec.batteries.item.model}</td>
                        <td className="py-2 px-3 text-center font-mono font-bold">{rec.batteries.count}</td>
                        <td className="py-2 px-3 font-mono">{formatPrice(rec.batteries.item.sale_price)}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(batteriesTotal)}</td>
                      </tr>
                    )}
                    <tr className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-center text-slate-400">3</td>
                      <td className="py-2 px-3 font-bold text-slate-800 flex items-center gap-1.5"><Zap className="w-3.5 h-3.5 text-blue-500" /> انفرتر</td>
                      <td className="py-2 px-3 text-slate-600 truncate max-w-[150px]">{rec.inverter.item.model}</td>
                      <td className="py-2 px-3 text-center font-mono font-bold">1</td>
                      <td className="py-2 px-3 font-mono">{formatPrice(rec.inverter.item.sale_price)}</td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(inverterTotal)}</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-center text-slate-400">4</td>
                      <td className="py-2 px-3 font-bold text-slate-800">ملحقات</td>
                      <td className="py-2 px-3 text-slate-500 text-[10px]">قواطع حماية، كابلات، هياكل تثبيت، مؤرض</td>
                      <td className="py-2 px-3 text-center font-mono">—</td>
                      <td className="py-2 px-3 font-mono text-slate-400">-</td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(Math.round(accessoriesCost))}</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-center text-slate-400">5</td>
                      <td className="py-2 px-3 font-bold text-slate-800">أجور عمل</td>
                      <td className="py-2 px-3 text-slate-500 text-[10px]">نقل، تركيب، تشغيل وبرمجة النظام</td>
                      <td className="py-2 px-3 text-center font-mono">—</td>
                      <td className="py-2 px-3 font-mono text-slate-400">-</td>
                      <td className="py-2 px-3 font-mono font-bold text-slate-800">{formatPrice(Math.round(installationCost))}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* 4. Bottom Section: Terms (Left) & Totals (Right) */}
            <div className="flex gap-6 mt-6 shrink-0">

              {/* Terms & Warranty */}
              <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-4">
                <h3 className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-emerald-500" /> الضمان والشروط العامة
                </h3>
                <div className="grid grid-cols-2 gap-2 text-[10px] mb-3 border-b border-slate-200 pb-3">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                    <span className="text-slate-600">الألواح: <strong>{warrantyPanels}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                    <span className="text-slate-600">البطاريات: <strong>{warrantyBatteries}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                    <span className="text-slate-600">المحول: <strong>{warrantyInverter}</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                    <span className="text-slate-600">التركيب: <strong>{warrantyLabor}</strong></span>
                  </div>
                </div>
                <ul className="text-[10px] text-slate-500 space-y-1 list-disc list-inside">
                  <li>الأسعار قابلة للتغيير وتعتمد على سعر الصرف وتوفر المواد وقت التجهيز.</li>
                  <li>العرض صالح لمدة 7 أيام من تاريخ الإصدار المنصوص أعلاه.</li>
                  <li>آلية الدفع: 50% مقدم، 30% توريد، 20% بعد التشغيل المبدئي.</li>
                </ul>
              </div>

              {/* Totals Calculation */}
              <div className="w-[240px] border border-slate-200 rounded-xl p-4 bg-white flex flex-col justify-between">
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>مجموع المعدات:</span>
                    <span className="font-mono">{formatPrice(Math.round(hardwareTotal))}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>ملحقات وتركيب:</span>
                    <span className="font-mono">{formatPrice(Math.round(accessoriesCost + installationCost))}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-bold border-b border-dashed border-emerald-200 pb-2">
                      <span>خصم خاص:</span>
                      <span className="font-mono">-{formatPrice(discount)}</span>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200">
                  <div className="flex justify-between items-end mb-1">
                    <span className="text-sm font-bold text-slate-900">الإجمالي النهائي</span>
                    <span className="text-xl font-black text-slate-900 font-mono">{formatPrice(Math.round(grandTotal))}</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* 5. Footer */}
          <div className="bg-slate-100 border-t border-slate-200 p-4 shrink-0 grid grid-cols-3 text-[10px] text-slate-500">
            <div className="text-right">Smart Solar Systems © 2026</div>
            <div className="text-center"> Baghdad, Iraq | info@smartsolar.iq </div>
            <div className="text-left font-mono">Printed on: {new Date().toLocaleString('en-GB')}</div>
          </div>

        </div>
      </div>
    </div>
  );
}
